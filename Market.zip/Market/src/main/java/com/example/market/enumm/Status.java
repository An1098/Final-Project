package com.example.market.enumm;

public enum Status {
    Принят, Оформлен, Ожидает, Получен
}
